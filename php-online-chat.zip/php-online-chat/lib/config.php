<?php

/* Database Host */
define('DB_HOST', '');

/* Database User Name */
define('DB_USER', '');

/* Database Password */
define('DB_PASS', '');

/* Database Name */
define('DB_DATABASENAME', '');

/* Database Default Charset */
define('DB_CHARSET', 'utf8mb4');

?>